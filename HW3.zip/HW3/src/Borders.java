import java.util.ArrayList;

/**
 * CS2 HW3 Borders.java 
 * Purpose: Used to identify if two countries border each other
 * 
 * @author grantschumacher
 * @version 1.0 9/15/17
 */
public class Borders {
	ArrayList<String> germanyArray = new ArrayList<String>();

	/**
	 * No argument constructor for Borders.java
	 */
	public Borders() {

	}
	
	/**
	 * Prints the borders of Germany (All items in germanyArray) to the console
	 */
	public void printBorders() {
		addCountries();
		for (int i = 0; i < germanyArray.size(); i++) {
			System.out.println("  --" + germanyArray.get(i));
		}
	}
	/**
	 * Populates germanyArray with all countries that border Germany
	 */
	private void addCountries() {
		germanyArray.add("Netherlands");
		germanyArray.add("Belgium");
		germanyArray.add("Luxembourg");
		germanyArray.add("Poland");
		germanyArray.add("CzechRepublic");
		germanyArray.add("Austria");
		germanyArray.add("France");
		germanyArray.add("Switzerland");
		
		

	}
}
