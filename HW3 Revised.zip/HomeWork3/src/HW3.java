import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;

/**
 * CS2 HW3 
 * HW3.java 
 * Purpose: Takes in user commands, prints and analyzes country data based off of commands.
 * 
 * @author grantschumacher
 * @version 2.0 10/2/17 (1.0 was created 9/15/17)
 */
public class HW3 {

	String line = null;
	String input;
	Boolean quitProgram = false;

	//Create array and linked list of countries
	ArrayList<Countries> countryArray = new ArrayList<Countries>();
	LinkedList<Countries> countryLL = new LinkedList<Countries>();
	
	//Create scanner for user input
	Scanner sc = new Scanner(System.in);
	
	//Create border object for accessing Border.java methods
	Borders germanyBorders = new Borders();
	
	public static void main(String[] args) {
		HW3 countryProject = new HW3();
	
		countryProject.createUserInterface();
	}

	/**
	 * Greets the user, shows commands with assigned numbers, loops for amount of uses desired by user
	 */
	public void createUserInterface() {

		System.out.println("-------------------------------------------------------------------");
		System.out.println("Welcome. Please type in the number of the option you wish to choose:");
		System.out.println("1. Import the data");
		System.out.println("2. Dipslay list of countries that border Germany");
		System.out.println("3. Display list of all countries that have a population greater than 35 million");
		System.out.println("4. Display list of all countries that border Germany and have a population greater than 35 million");
		System.out.println("5. Quit the program");
		System.out.println("-------------------------------------------------------------------");

		while (quitProgram == false) {
			input = sc.next();
			switch (input) {
			case "1":
				System.out.println("What is the name of the file you wish to load?");
				input = sc.next();
				loadFileToLists(input);
				
				System.out.println("-------------------------------------------------------------------");
				break;

			case "2":
				System.out.println("-------------------------------------------------------------------");
				System.out.println("The Countries that border with Germany are:");
				germanyBorders.printBorders();
				System.out.println("-------------------------------------------------------------------");
				break;
				
			case "3":
				System.out.println("-------------------------------------------------------------------");
				System.out.println("The Countries that have a population > 35 million are:");
				checkPopulation();
				System.out.println("-------------------------------------------------------------------");
				break;
				
			case "4":
				System.out.println("-------------------------------------------------------------------");
				System.out.println("The Countries that have a population > 35 million and border Germany are:");
				checkBordersAndPopulation();
				System.out.println("-------------------------------------------------------------------");
				break;
				
			case "5":
				System.out.println("Quitting Program");
				quitProgram = true;
				break;
				
			case "h":
				System.out.println("-------------------------------------------------------------------");
				System.out.println("1. Import the data");
				System.out.println("2. Dipslay list of countries that border Germany");
				System.out.println("3. Display list of all countries that have a population greater than 35 million");
				System.out.println("4. Display list of all countries that border Germany and have a population greater than 35 million");
				System.out.println("5. Quit the program");
				System.out.println("-------------------------------------------------------------------");
				break;
			}
			if (quitProgram == false) { //Only prompt user to enter command if they wish to continue (quitProgram == false)
				System.out.println("Please enter your next command digit or type h to list them again:");
			} else { //Otherwise, closes the scanner and exits the loop
				sc.close();
				break;
			}
		}
	}


	/**
	 * Takes in user's file name and populates fields in countryArray and countryLL
	 * @param fileName
	 */
	public void loadFileToLists(String fileName) {

		try {
			String name;
			int index = 0;
			FileReader fr = new FileReader(fileName);
			BufferedReader br = new BufferedReader(fr);
			
			while((name = br.readLine()) != null){
				String latitude = br.readLine();	
				String longitude = br.readLine();				
				int area = Integer.parseInt(br.readLine());			
				int population = Integer.parseInt(br.readLine());
				double GDP = Double.parseDouble(br.readLine())* 1000000000;
				int year = Integer.parseInt(br.readLine());
				germanyBorders.addBorderCountry(index, name); //Adds bordering countries of Germany
				countryArray.add(new Countries(name, latitude, longitude, area, population, GDP, year)); //Populates country at index i
				countryLL.add(new Countries(name, latitude, longitude, area, population, GDP, year)); //Populates country and appends to linked list
				index++;
			}
			
			br.close();
		} catch (Exception ex) {

			System.out.println("  --Failed to locate specified file");
			System.out.println(ex);
		}
	}
	
	/**
	 * Checks the population of every country in countryArray / countryLL and prints country name if population is > 35 million
	 */
	public void checkPopulation() {
		for (int i = 0; i < countryArray.size(); i++) {
			if (countryArray.get(i).getCountryPopulation() > 35000000) {
				System.out.println("  --" + countryArray.get(i).getCountryName());
			}
		}
	}
	
	
	/**
	 * Prints the countries with a population > 35 million that border Germany
	 */
	public void checkBordersAndPopulation() {
		for (int i = 0; i < countryArray.size(); i++) {
			if(countryArray.get(i).getCountryName() != "Germany"){
				if (countryArray.get(i).getCountryPopulation() > 35000000) { 
					System.out.println("  --" + countryArray.get(i).getCountryName());
				}
			}
		}
	}
}
