import java.util.ArrayList;
/**
 * CS2 HW3 
 * Borders.java 
 * Purpose: Used to identify that two countries border each other.
 * 
 * @author grantschumacher
 * @version 2.0 10/2/17 (1.0 was created 9/15/17)
 */


public class Borders {
	ArrayList<String> borders = new ArrayList<String>();;
	
	/**
	 * Constructor for Borders.java
	 * @param numberOfBorders
	 */
	public Borders() {
		
	}
	/**
	 * Adds the name of a country that borders at a given index
	 * @param index
	 * @param name
	 */
	public void addBorderCountry(int index, String name){
		borders.add(index, name);
	}
	
	/**
	 * Gets the array of all borders specified for country
	 * @return
	 */
	public ArrayList<String> getBorders(){
		return borders;
	}
	
	/**
	 * Prints names of all countries that border with specified country
	 */
	public void printBorders(){
		for(String name : borders){
			System.out.println("  --"+ name);
		}
	}
}
